#ifndef _LISTA_H
#define _LISTA_H


typedef struct _lista lista;


lista *iniLista(void);
lista *getProxElementoLista(lista *m);




#endif